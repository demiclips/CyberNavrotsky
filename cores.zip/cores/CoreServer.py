import socket
import threading
import hashlib
import time

HOST = '0.0.0.0'
PORT = 5000
TARGET_HASH = "EC9C0F7EDCC18A98B1F31853B1813301".lower()  # Convert to lowercase because hashlib.hexdigest() outputs lowercase hex
BATCH_SIZE = 5000000
MAX_NUM = 10000000000

current_num = 0
returned_batches = []
connected_cores = []
total_cores = 0
start_time = None
solution_found = False


def get_next_batch():
    '''

    :return: send the next batch according to if it is over the lim or it found the soloution
    '''
    global current_num

    if solution_found:
        return "STOP"

    if len(returned_batches) > 0:
        return returned_batches.pop(0)

    if current_num >= MAX_NUM:
        return "STOP"

    batch = f"{current_num}-{current_num + BATCH_SIZE}"
    current_num += BATCH_SIZE
    return batch


def handle_core(conn, addr):
    '''

    :param conn: conection provides the socket connection
    :param addr: the addres it talks to
    :return: handles each core that ois connected and send him the batch and checks if he
    foiund the correct one
    '''
    global solution_found, total_cores, start_time

    if start_time is None:
        start_time = time.time()

    total_cores += 1
    print(f"Processor connected from: {addr[0]}")
    connected_cores.append(conn)
    my_batch = None

    try:
        while not solution_found:
            msg = conn.recv(1024).decode()
            if not msg:
                break

            if msg == "GET_WORK" or msg == "NOT_FOUND":
                my_batch = get_next_batch()
                conn.send(my_batch.encode())
                if my_batch == "STOP":
                    my_batch = None
                    break

            elif msg.startswith("FOUND:"):
                candidate = msg.split(":")[1]#(found : num)
                hashed = hashlib.md5(candidate.encode()).hexdigest() #i check

                if hashed == TARGET_HASH:
                    elapsed_time = time.time() - start_time
                    print(f"Original string: {candidate}")
                    print(f"Processors worked: {total_cores}")
                    print(f"Processing time: {elapsed_time} seconds")


                    solution_found = True
                    my_batch = None
                    #closes all cores
                    for c in connected_cores:
                        try:
                            c.send("STOP".encode())
                            c.close()
                        except Exception:
                            pass
                    server_socket.close()
                    break
                else:
                    print(f"WRONG answer '{candidate}' from {addr}! Cutting link and recycling batch {my_batch}.")
                    break

    except Exception:
        pass
    finally: #at the end kill all the connections and close the connections
        if conn in connected_cores:
            connected_cores.remove(conn)
        if my_batch is not None and not solution_found:
            returned_batches.append(my_batch)
        conn.close()


server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind((HOST, PORT))
server_socket.listen()
print("Server is waiting for cores...")

while not solution_found:
    try:
        conn, addr = server_socket.accept()
        t = threading.Thread(target=handle_core, args=(conn, addr))
        t.start()
    except OSError:
        break