import multiprocessing
import socket
import hashlib

SERVER_IP = '127.0.0.1'  # change for server
SERVER_PORT = 5000
TARGET_HASH = "EC9C0F7EDCC18A98B1F31853B1813301".lower()


def core_worker(core_id):
    '''

    :param core_id: the specific core that is running
    :return: runs the single core to find the number
    '''
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        client_socket.connect((SERVER_IP, SERVER_PORT))
        print(f"Core {core_id} connected to server!")

        #ask for the very first batch of numbers
        client_socket.send("GET_WORK".encode())

        while True:
            # wait for the server to send a batch or STOP
            response = client_socket.recv(1024).decode()

            if not response or response == "STOP":
                print(f"Core {core_id} stopping.")
                break

            print(f"Core {core_id} checking range: {response}")

            start_str, end_str = response.split("-")
            start_num = int(start_str)
            end_num = int(end_str)

            # 3. Check every number in this batch
            found = False
            for num in range(start_num, end_num):
                candidate = str(num).zfill(10)
                hashed = hashlib.md5(candidate.encode()).hexdigest()

                if hashed == TARGET_HASH:
                    print(f"Core {core_id} FOUND IT: {candidate}")
                    client_socket.send(f"FOUND:{candidate}".encode())
                    found = True
                    break

            #if found wait for response to close
            if found:
                final_msg = client_socket.recv(1024).decode()
                break
            else:
                #didnt find new batch
                client_socket.send("NOT_FOUND".encode())

    except Exception:
        print(f"Core {core_id} disconnected from server.")
    finally:
        client_socket.close()


if __name__ == '__main__':
    num_cores = multiprocessing.cpu_count()
    print(f"Found {num_cores} cores. Spawning independent clients...")

    for i in range(num_cores):
        p = multiprocessing.Process(target=core_worker, args=(i,))
        p.start()