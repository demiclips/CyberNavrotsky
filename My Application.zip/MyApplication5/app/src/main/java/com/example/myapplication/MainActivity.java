package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText etName;
    EditText etPhone;
    Button btnContinue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);



        etName = findViewById(R.id.editTextPersonName);
        etPhone = findViewById(R.id.editTextPhone2);
        btnContinue = findViewById(R.id.button);

        btnContinue.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        String name,phone;
        if (view.getId() == R.id.button)
        {
            name = etName.getText().toString();
            phone = etPhone.getText().toString();

            if (name.equals("") || phone.equals("")) {
                Toast.makeText(this, "you must enter name && phone", Toast.LENGTH_LONG).show();
            }
            else {
                Toast.makeText(this, name + " , " + phone, Toast.LENGTH_LONG).show();
                Intent i = new Intent(this, MainActivity2.class);
                i.putExtra("NAME", name);
                i.putExtra("PHONE", phone);
                startActivity(i);
            }
        }


    }
}