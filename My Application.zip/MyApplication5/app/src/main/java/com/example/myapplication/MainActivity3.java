package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity3 extends AppCompatActivity implements View.OnClickListener {

    TextView tvName, tvOrder, tvPrice;
    Button btnReturn, btnContinue;

    String rawName = "";
    int totalPrice = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        tvName = findViewById(R.id.name);
        tvOrder = findViewById(R.id.tvOrder);
        tvPrice = findViewById(R.id.tvPrice);

        btnReturn = findViewById(R.id.button1);
        btnContinue = findViewById(R.id.button2);

        btnReturn.setOnClickListener(this);
        btnContinue.setOnClickListener(this);

        Intent intent = getIntent();
        if (intent != null) {
            rawName = intent.getStringExtra("NAME");
            String size = intent.getStringExtra("SIZE");
            String[] toppings = intent.getStringArrayExtra("TOPPINGS");

            tvName.setText("Hello " + rawName);

            if (size.contains("small")) {
                totalPrice = 10;
            }
            else if (size.contains("medieum")) {
                totalPrice = 20;
            }
            else if (size.contains("large")) {
                totalPrice = 25;
            }

            StringBuilder orderDetails = new StringBuilder();
            orderDetails.append(size);

            if (toppings != null && toppings.length > 0) {
                int toppingPrice = 1; // Change this if each topping costs a different amount
                totalPrice += toppings.length * toppingPrice;

                for (int i = 0; i < toppings.length; i++) {
                    orderDetails.append(", ").append(toppings[i]);
                }
            }

            tvOrder.setText(orderDetails.toString());
            tvPrice.setText("price: " + totalPrice + "₪");
        }
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.button1) {
            finish();
        }
        else if (view.getId() == R.id.button2) {

            btnContinue.setEnabled(false);

            final String customerName = tvName.getText().toString();
            final String orderDetails = tvOrder.getText().toString();
            final String orderPrice = tvPrice.getText().toString();

            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        java.net.URL url = new java.net.URL("http://10.0.2.2:5000/receive_order");
                        java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();

                        conn.setRequestMethod("POST");
                        conn.setRequestProperty("Content-Type", "application/json; utf-8");
                        conn.setDoOutput(true);

                        String jsonInputString = "{\"name\": \"" + customerName + "\", \"order\": \"" + orderDetails + "\", \"price\": \"" + orderPrice + "\"}";

                        try (java.io.OutputStream os = conn.getOutputStream()) {
                            byte[] input = jsonInputString.getBytes("utf-8");
                            os.write(input, 0, input.length);
                        }

                        int responseCode = conn.getResponseCode();
                        System.out.println("Python Server Response Code: " + responseCode);

                        //move to 4
                        if (responseCode == 200) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Intent nextIntent = new Intent(MainActivity3.this, MainActivity4.class);
                                    nextIntent.putExtra("NAME", rawName);
                                    nextIntent.putExtra("PRICE", totalPrice);
                                    startActivity(nextIntent);
                                }
                            });
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }
    }
}