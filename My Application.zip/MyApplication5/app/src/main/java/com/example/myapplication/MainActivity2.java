package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity {
    TextView tvWelcome;
    String name = "", phone = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main2);
        tvWelcome = findViewById(R.id.tvWelcome);

        Intent i = getIntent();
        if (i != null){
            name = i.getStringExtra("NAME");
            phone = i.getStringExtra("PHONE");
        }
        tvWelcome.setText("Welcome "+ name);
    }


}