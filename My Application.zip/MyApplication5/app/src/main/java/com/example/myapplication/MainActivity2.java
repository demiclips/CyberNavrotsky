package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity implements View.OnClickListener {
    TextView tvWelcome;
    String name = "", phone = "";
    RadioButton small, medium, large;
    CheckBox olives, corn, tomato, pineapple, mushrooms;
    Button btnContinue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main2);
        tvWelcome = findViewById(R.id.tvWelcome);
        small = findViewById(R.id.small);
        medium = findViewById(R.id.medium);
        large = findViewById(R.id.large);

        olives = findViewById(R.id.olives);
        corn = findViewById(R.id.corn);
        tomato = findViewById(R.id.tomato);
        pineapple = findViewById(R.id.pineapple);
        mushrooms = findViewById(R.id.mushrooms);

        btnContinue = findViewById(R.id.Continue);
        btnContinue.setOnClickListener(this); // Register this activity as the listener

        Intent i = getIntent();
        if (i != null){
            name = i.getStringExtra("NAME");
            phone = i.getStringExtra("PHONE");
        }
        tvWelcome.setText("Welcome "+ name);
    }

    @Override
    public void onClick(View view)  {
        if (view.getId() == R.id.Continue) {
            String size = "";
            if (small.isChecked()) {
                size = "small (10₪)";
            }
            else if (medium.isChecked()) {
                size = "medieum (20₪)";
            }
            else if (large.isChecked()) {
                size = "large (25₪)";
            }

            // Check if user forgot to pick a size
            if (size.equals("")) {
                Toast.makeText(this, "you must choose a pizza size", Toast.LENGTH_LONG).show();
            }
            else {
                // List for all toppings
                java.util.List<String> tempList = new java.util.ArrayList<>();

                if (olives.isChecked()) {
                    tempList.add("olives");
                }
                if (corn.isChecked()) {
                    tempList.add("corn");
                }
                if (tomato.isChecked()) {
                    tempList.add("tomato");
                }
                if (pineapple.isChecked()) {
                    tempList.add("pineapple");
                }
                if (mushrooms.isChecked()) {
                    tempList.add("mushrooms");
                }

                String[] toppings = tempList.toArray(new String[0]);

                Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                intent.putExtra("NAME", name);
                intent.putExtra("PHONE", phone);
                intent.putExtra("SIZE", size);
                intent.putExtra("TOPPINGS", toppings);
                startActivity(intent);
            }
        }
    }
}