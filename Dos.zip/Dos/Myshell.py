import os
import subprocess
import getpass


# find the directory where the files are inside
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

print("type " + "?" + " for help, type exit to exit")
if __name__ == "__main__":
    while True:
        # display the dir where the current working directory (not same as base_dir)
        current_dir = os.getcwd()

        user_input = input(f"{current_dir}>>> ").strip()

        if not user_input:  # presses enter
            continue

        #if there is a file extract it
        out_file = None
        if ">" in user_input:
            user_input, out_file_str = user_input.split(">", 1)
            out_file = out_file_str.strip()


        #Split into a list of commands by Pipe (|) , if not then regular cmd
        pipe_commands = []
        for cmd in user_input.split("|"):
            pipe_commands.append(cmd.strip())

        #check for commands if user inputed
        first_cmd_parts = pipe_commands[0].split(maxsplit=1)
        cmd = first_cmd_parts[0].lower()

        if len(first_cmd_parts) > 1:
            args = first_cmd_parts[1]
        else:
            args = ""

        #if there are no pipes and regular no call command (stays in myshell.py)
        if len(pipe_commands) == 1 and cmd in ["exit", "?", "cls", "cd", "hello"]:
            if cmd == "exit":
                break
            elif cmd == "?":
                print("\n--- MyShell Available Commands ---")
                print("  hello           - Prints greeting with the logged-in user")
                print("  ls [dir]        - Lists contents of current or target directory")
                print("  cd [path]       - Changes current directory")
                print("  hexdump <file>  - Displays file contents in hexadecimal")
                print("  grep <text> [f] - Searches for text pattern")
                print("  cls             - Clears the screen")
                print("  exit            - Exits the shell\n")
            elif cmd == "cls":
                os.system("cls")
            elif cmd == "cd":
                if not args:
                    print(os.getcwd())
                else:
                    try:
                        os.chdir(args)
                    except Exception as e:
                        print(e)
            elif cmd == "hello":
                username = getpass.getuser()
                print(f"hello {username}")

            continue  #skip the external command loop since we already handled it

        #command that go outside of Myshell, need for pipe
        previous_output = None

        for i in range(len(pipe_commands)):
            # Split the current command into words
            current_cmd_parts = pipe_commands[i].split()

            if len(current_cmd_parts) == 0:
                continue

            exe_name = current_cmd_parts[0].lower()  #ls grep and hexdump

            #grab all the arguments after the command name using a simple loop
            cmd_args = []
            for j in range(1, len(current_cmd_parts)):
                cmd_args.append(current_cmd_parts[j])

            #point directly to the .bat file in your BASE_DIR
            bat_path = os.path.join(BASE_DIR, exe_name + ".bat")

            #one list
            run_list = [bat_path]
            for arg in cmd_args:
                run_list.append(arg)

            is_last_command = (i == len(pipe_commands) - 1)

            try:
                #if last command and a file then insert
                if is_last_command and out_file is not None:
                    with open(out_file, "wb") as f:
                        subprocess.run(run_list, input=previous_output, stdout=f)

                #otherwise, run it and capture the output
                else:
                    result = subprocess.run(run_list, input=previous_output, capture_output=True)
                    previous_output = result.stdout

                    #if last command then print it
                    if is_last_command and previous_output is not None:
                        print(previous_output.decode("utf-8", errors="ignore"), end="")

            except Exception as e:
                print(f"Error running {exe_name}: {e}")
                break