import sys
import os

def display_hexdump(data: bytes):
    """Prints binary data formatted into address offset, hex values, and ASCII representation."""
    offset = 0
    chunk_size = 16

    while offset < len(data):
        chunk = data[offset:offset + chunk_size]

        #changes from bytes to hexa
        hex_str = ' '.join(f"{b:02x}" for b in chunk)


        #prints like the cmd
        print(f"{hex_str:<48}")
        offset += chunk_size

def main():
    data = b""

    #passe an argument (hexdump filename.txt)
    if len(sys.argv) > 1:
        file_path = sys.argv[1]
        if not os.path.isfile(file_path):
            print(f"File not found: {file_path}")
            return
        with open(file_path, "rb") as f:
            data = f.read()

    #passed by pipe
    elif not sys.stdin.isatty():
        data = sys.stdin.buffer.read()

    else:
        print("Please provide a valid file")
        return
    display_hexdump(data)

if __name__ == "__main__":
    main()