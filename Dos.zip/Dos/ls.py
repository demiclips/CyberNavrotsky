import os
from logging import exception
import sys

if __name__ == "__main__":
    target_dir = os.getcwd()

    if len(sys.argv) > 1:#if he inputs a dir then use it instead
        target_dir = sys.argv[1]
        # Check if the target is a valid directory before trying to list it
    if not os.path.isdir(target_dir):
        print(f"Directory not found: {target_dir}")
    else:
        try:
            # Get the list of files and folders
            contents = os.listdir(target_dir)

            # Print each item on a new line
            for item in contents:
                print(item)

        except Exception as e:
            print(e)