import sys
import os

def search_text(lines, pattern):
    """Searches for pattern in lines and prints line numbers with matching content."""
    line_num = 1
    for line in lines:
        clean_line = line.rstrip("\r\n")#right strip to end the line wont go down in prints
        if pattern in clean_line:
            print(f"{line_num}: {clean_line}")
        line_num += 1

def main():
    if len(sys.argv) < 2:
        print("Error, type: grep search_string [file_path]")
        return

    pattern = sys.argv[1]

    # Case 1: File path provided (e.g., grep hello Ls.bat)
    if len(sys.argv) >= 3:
        file_path = sys.argv[2]
        if not os.path.isfile(file_path):
            print(f"File not found: {file_path}")
            return
        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                lines = f.readlines()
            search_text(lines, pattern)
        except Exception as e:
            print(f"Error reading file: {e}")

    #reading from piped stdin
    elif not sys.stdin.isatty():
        try:
            lines = sys.stdin.readlines()
            search_text(lines, pattern)
        except Exception as e:
            print(f"Error reading stdin: {e}")

    else:
        print("Usage: grep <search_string> [file_path]")

if __name__ == "__main__":
    main()